package com.example.exp10;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    private EditText nameEdt, courseEdt, uidEdt, sectionEdt;
    private Button addStudentBtnEdt;
    private DBHandler dbHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nameEdt = findViewById(R.id.idName);
        courseEdt = findViewById(R.id.idCourse);
        uidEdt = findViewById(R.id.idUID);
        sectionEdt = findViewById(R.id.idSection);
        addStudentBtnEdt = findViewById(R.id.idBtnAddStudent);
        dbHandler = new DBHandler(MainActivity.this);
        addStudentBtnEdt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEdt.getText().toString();
                String course = courseEdt.getText().toString();
                String uid = uidEdt.getText().toString();
                String section = sectionEdt.getText().toString();
                if (name.isEmpty() && course.isEmpty() && uid.isEmpty() && section.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }
                dbHandler.addNewStudent(name, course, uid, section);
                Toast.makeText(MainActivity.this, "Student has been added.", Toast.LENGTH_SHORT).show();
                nameEdt.setText("");
                courseEdt.setText("");
                uidEdt.setText("");
                sectionEdt.setText("");
            }
        });
    }
}
